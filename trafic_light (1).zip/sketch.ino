
// Jalur 1
const int j1_hijau = 13;
const int j1_kuning = 12;
const int j1_merah = 14;

// Jalur 2
const int j2_hijau = 27;
const int j2_kuning = 26;
const int j2_merah = 25;

// Jalur 3
const int j3_hijau = 33;
const int j3_kuning = 32;
const int j3_merah = 4;

// Jalur 4
const int j4_hijau = 16;
const int j4_kuning = 17;
const int j4_merah = 5;

void setup() {
  pinMode(j1_hijau, OUTPUT);
  pinMode(j1_kuning, OUTPUT);
  pinMode(j1_merah, OUTPUT);

  pinMode(j2_hijau, OUTPUT);
  pinMode(j2_kuning, OUTPUT);
  pinMode(j2_merah, OUTPUT);

  pinMode(j3_hijau, OUTPUT);
  pinMode(j3_kuning, OUTPUT);
  pinMode(j3_merah, OUTPUT);

  pinMode(j4_hijau, OUTPUT);
  pinMode(j4_kuning, OUTPUT);
  pinMode(j4_merah, OUTPUT);
}

void loop() {
 digitalWrite(j1_hijau, HIGH);
 digitalWrite(j1_kuning, LOW);
 digitalWrite(j1_merah, LOW);
 delay(500);
 digitalWrite(j1_hijau, LOW);
 digitalWrite(j1_kuning, HIGH);
 digitalWrite(j1_merah, LOW);
 delay(500);
 digitalWrite(j1_hijau, LOW);
 digitalWrite(j1_kuning, LOW);
 digitalWrite(j1_merah, HIGH);
 delay(500);
 digitalWrite(j2_hijau, HIGH);
 digitalWrite(j2_kuning, LOW);
 digitalWrite(j2_merah, LOW);
 delay(500);
  digitalWrite(j2_hijau, LOW);
 digitalWrite(j2_kuning, HIGH);
 digitalWrite(j2_merah, LOW);
 delay(500);
  digitalWrite(j2_hijau, LOW);
 digitalWrite(j2_kuning, LOW);
 digitalWrite(j2_merah, HIGH);
 delay(500);
 digitalWrite(j3_hijau, HIGH);
 digitalWrite(j3_kuning, LOW);
 digitalWrite(j3_merah, LOW);
 delay(500);
  digitalWrite(j3_hijau,LOW);
 digitalWrite(j3_kuning,  HIGH);
 digitalWrite(j3_merah, LOW);
 delay(500);
   digitalWrite(j3_hijau,LOW);
 digitalWrite(j3_kuning, LOW);
 digitalWrite(j3_merah, HIGH);
 delay(500);
 digitalWrite(j4_hijau, HIGH);
 digitalWrite(j4_kuning, LOW);
 digitalWrite(j4_merah, LOW);
 delay(500);
 digitalWrite(j4_hijau, LOW);
 digitalWrite(j4_kuning, HIGH);
 digitalWrite(j4_merah, LOW);
 delay(500);
 digitalWrite(j4_hijau, LOW);
 digitalWrite(j4_kuning, LOW);
 digitalWrite(j4_merah, HIGH);
 delay(500);
}